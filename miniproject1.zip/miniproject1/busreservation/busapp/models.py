from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Bus(models.Model):
    bus_number = models.CharField(max_length=20, default=0)
    origin = models.CharField(max_length=255, default='Unknown Origin')
    destination = models.CharField(max_length=255, default='Unknown Destination')
    departure_time = models.DateTimeField(default=timezone.now)
    seats_available = models.IntegerField()
    
    def __str__(self):
        return f"{self.bus_number} from {self.origin} to {self.destination}"

    # def __str__(self):
    #     return f"{self.bus_number} from {self.origin} to {self.destination}"

class Reservation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    passenger_name = models.CharField(max_length=100)
    number_of_passengers = models.IntegerField()
    date_of_travel = models.DateField()

    def __str__(self):
        return f"Reservation by {self.passenger_name} on {self.date_of_travel} for bus {self.bus.bus_number}"
    # def __str__(self):
    #     return f"Reservation by {self.passenger_name} on {self.date_of_travel} for bus {self.bus.bus_number}"
