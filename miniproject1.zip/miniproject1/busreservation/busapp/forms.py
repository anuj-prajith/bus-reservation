from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.contrib import admin

class CustomUserCreationForm(UserCreationForm):
    phone_number = forms.CharField(required=True, max_length=15)
    address = forms.CharField(required=False, widget=forms.Textarea)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'phone_number', 'address', 'password1', 'password2')
    # class Meta:
    #     model = User
    #     fields = ('username', 'email', 'phone_number', 'address', 'password1', 'password2')