from django.conf import settings
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm
from django.http import HttpResponse
from django.http import HttpResponseBadRequest
from .models import Bus,Reservation
from django.views.decorators.csrf import csrf_exempt


# Create your views here.
@login_required
def home(request):
    return render(request,"home.html")
def loginview(request):
    uname=request.POST['username']     
    pwd=request.POST["password"]        
    user=authenticate(request,username=uname,password=pwd)
    if user is not None:              
        login(request,user)
        return redirect('home')
    else:
        return render(request,'registration\login.html',{"msg":"Invalid login"})
    
def logoutview(request):
    logout(request)
    return redirect('login')

def sign_up(request):
        if request.method == "POST":
            form = CustomUserCreationForm(request.POST)
            if form.is_valid():
                user = form.save(commit=False)  
                user.phone_number = form.cleaned_data['phone_number']
                user.address = form.cleaned_data['address']
                user.save()  
                return redirect('login')
            else:
                return render(request, 'signup.html', {'form': form, 'msg': 'Invalid signup details'})
 
        form = CustomUserCreationForm()
        return render(request, 'signup.html', {'form': form})

def reset_passtopg(request):
    return render(request,"resetpass.html")

def reset_pass(request):
    uname= request.POST['uname']
    newpwd= request.POST['password']
    try:
        user=User.objects.get(username=uname)
        if user is not None:
            user.set_password(newpwd)      
            user.save()
            return render(request,'resetpass.html',{"msg":"Password Reset Successfully"})
    except Exception as e:
        print(e)
        return render(request,"resetpass.html",{"msg":"Password Reset Failed"})


    
@login_required
def reservation(request):
    if request.method == "POST":
        passenger_name = request.POST.get('Name')
        origin = request.POST.get('from')
        destination = request.POST.get('to')
        travel_date = request.POST.get('date')
        number_of_passengers = request.POST.get('passengers')

        # Store data in session
        request.session['reservation_data'] = {
            'name': passenger_name,
            'origin': origin,
            'destination': destination,
            'date': travel_date,
            'passengers': number_of_passengers
        }

        return redirect('ticket')  # Redirect to ticket details page

    return render(request, 'reservation.html')


@login_required
def ticket_details(request):
    # Retrieve reservation data from the session
    reservation_data = request.session.get('reservation_data')
    if not reservation_data:
        return redirect('reserv')  # Redirect back to reservation page if no data found

    # Calculate amount based on the number of passengers
    price_per_passenger = 500  # Example price
    total_amount = int(reservation_data['passengers']) * price_per_passenger

    # Pass data to template
    return render(request, 'ticket_details.html', {
        'reservation_data': reservation_data,
        'total_amount': total_amount
    })


@login_required
def payment_page(request):
    # Retrieve reservation data from session
    reservation_data = request.session.get('reservation_data')
    if not reservation_data:
        return redirect('reserv')  # Redirect back to reservation page if no data found

    if request.method == "POST":
        # Mock payment success
        return redirect('success')

    return render(request, 'payment.html')


@login_required
def success_page(request):
    # Clear session data after successful booking
    request.session.pop('reservation_data', None)
    return render(request, 'success.html')


