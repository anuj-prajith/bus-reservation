from django.urls import path
from .import views

urlpatterns = [
    path("",views.home,name="home"),
    path("accounts/login/",views.loginview,name="login"),    
    path("logout",views.logoutview),
    path("accounts/sign_up/",views.sign_up,name="Register"),    
    path("resetp",views.reset_passtopg,name="reset"),
    path("passwordreset",views.reset_pass),
    path('reserv',views.reservation,name='reserv'),
    path('ticket/', views.ticket_details, name='ticket'),
    path('payment/', views.payment_page, name='payment'),
    path('success/', views.success_page, name='success'),
]