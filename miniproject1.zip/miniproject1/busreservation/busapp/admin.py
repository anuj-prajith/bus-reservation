from django.contrib import admin
from .models import Bus, Reservation

class BusAdmin(admin.ModelAdmin):
    list_display = ('bus_number', 'origin', 'destination', 'departure_time', 'seats_available')
    search_fields = ('bus_number', 'origin', 'destination')

class ReservationAdmin(admin.ModelAdmin):
    list_display = ('user', 'bus', 'passenger_name', 'number_of_passengers', 'date_of_travel')
    search_fields = ('passenger_name', 'bus__bus_number')

admin.site.register(Bus, BusAdmin)
admin.site.register(Reservation, ReservationAdmin)
